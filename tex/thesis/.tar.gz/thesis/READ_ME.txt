make   : コンパイル
make a : pdfファイルの閲覧


たぶん EUC じゃないと文字化けする

$platex --version

とコマンドを入力することで最初の行に(EUC)とか(SJIS)と表示されるので tex ファイルをその文字コードに変換すること

(*
そんなの表示されない，という人はそもそもplatexが入ってないので入れてください
Ubuntu ソフトウェアセンターにて latex で検索をかけて
"Texmaker(Latex開発環境)"をインストールすれば大丈夫だと思います
*)


文字コードの変換方法はとりあえず二種類

/* --- emacs を使うパターン ---*/

C-x [RET] f

か

ESC-x set-buffer-file-coding-system

と入力するとemacsの下部に

Coding system for saving file (default nil):

と表示されるので

EUC なら euc-japan
JIS なら junet
SJISなら sjis

と入力する

/* --- nkf コマンドを使うパターン --- */

EUC なら
$nkf -e --overwrite [file]

JIS なら
$nkf -j --overwrite [file]

SJISなら
$nkf -s --overwrite [file]

 と入力する
